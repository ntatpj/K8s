For enforcing star network policy refer to this link: 

https://docs.projectcalico.org/v2.3/getting-started/kubernetes/tutorials/stars-policy/

